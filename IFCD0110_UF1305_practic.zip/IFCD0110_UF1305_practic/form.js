let checkNameSubmit = false;
let checLastNameSubmit = false;
let checkEmailSubmit = false;
let checkPassSubmit = false;
let checkDNISubmit = false;
let checkTextAreaSubmit = false;
let checkCitiesSubmit = false;
let checkConditionsSubmit = false;
const submitButtonElement = document.getElementById("submitButton");
const countCharsElement = document.getElementById("form_count_chars_b");
const fNameElement = document.getElementById("fname");
const nameErrorExplainElement = document.getElementById("nameErrorExplain");
const emailElement = document.getElementById("email");
const emailErrorExplainElement = document.getElementById("emailErrorExplain");
const checkPassElement = document.getElementById("password");
const passElement = document.getElementById("passExplain");

const letras = [
	"T",
	"R",
	"W",
	"A",
	"G",
	"M",
	"Y",
	"F",
	"P",
	"D",
	"X",
	"B",
	"N",
	"J",
	"Z",
	"S",
	"Q",
	"V",
	"H",
	"L",
	"C",
	"K",
	"E",
	"T",
];
function checkSubmitButton() {
	if (
		checkNameSubmit == true &&
		checLastNameSubmit == true &&
		checkEmailSubmit == true &&
		checkPassSubmit == true &&
		checkDNISubmit == true &&
		checkTextAreaSubmit == true &&
		checkCitiesSubmit == true &&
		checkConditionsSubmit
	) {
		submitButtonElement.disabled = false;
	}
}
function checkName(text) {
	text = text.trim();
	text = text.split(" ");
	if (text.length > 1) {
		if (text[0].length >= 2 && text[1].length >= 2) {
			checkNameSubmit = true;
			fNameElement.classList.add("correcte");
			fNameElement.classList.remove("corregir");
			nameErrorExplainElement.style.visibility = "hidden";
		} else {
			fNameElement.classList.add("corregir");
			fNameElement.classList.remove("correcte");
			nameErrorExplainElement.style.visibility = "visible";
			nameErrorExplainElement.innerHTML =
				"El nom compost ha de tenir minim 2 lletres cada un.";
			checkNameSubmit = false;
		}
	} else {
		if (text[0].length >= 2) {
			fNameElement.classList.add("correcte");
			fNameElement.classList.remove("corregir");
			nameErrorExplainElement.style.visibility = "hidden";

			checkNameSubmit = true;
		} else {
			fNameElement.classList.add("corregir");
			fNameElement.classList.remove("correcte");
			nameErrorExplainElement.style.visibility = "visible";
			nameErrorExplainElement.innerHTML = "El nom ha de tenir minim 2 lletres.";
			checkNameSubmit = false;
		}
	}
	if (text == "") {
		fNameElement.classList.remove("corregir");
		fNameElement.classList.remove("correcte");
		nameErrorExplainElement.style.visibility = "hidden";
	}
	checkSubmitButton();
}
const lNameErrorExplainElement = document.getElementById("lNameErrorExplain");
const lNameElement = document.getElementById("lname");
function checLastName(text) {
	let count = 0;
	text = text.trim();
	text = text.split(" ");
	if (text.length > 1) {
		for (let i = 0; i < text.length; i++) {
			if (text[i].length >= 3) {
				count++;
			}
		}
	}
	if (count == text.length) {
		lNameErrorExplainElement.style.visibility = "hidden";
		lNameElement.classList.remove("corregir");
		lNameElement.classList.add("correcte");
		checLastNameSubmit = true;
	} else {
		lNameElement.classList.remove("correcte");
		lNameElement.classList.add("corregir");
		lNameErrorExplainElement.style.visibility = "visible";
		lNameErrorExplainElement.innerHTML = "Ha de tenir 2 paraules amb 3 lletres";
		checLastNameSubmit = false;
	}
	if (text == "") {
		lNameElement.classList.remove("corregir");
		lNameElement.classList.remove("correcte");
		lNameErrorExplainElement.style.visibility = "hidden";
	}
	checkSubmitButton();
}

function checkEmail(email) {
	let test = email.match(
		/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
	);
	if (test != null) {
		emailErrorExplainElement.style.visibility = "hidden";
		emailElement.classList.add("correcte");
		emailElement.classList.remove("corregir");
		checkEmailSubmit = true;
	} else {
		emailErrorExplainElement.style.visibility = "visible";
		emailErrorExplainElement.innerHTML = "Introdueixi un email";
		emailElement.classList.add("corregir");
		emailElement.classList.remove("correcte");
		checkEmailSubmit = true;
	}
	if (email == "") {
		emailElement.classList.remove("corregir");
		emailElement.classList.remove("correcte");
		emailErrorExplainElement.style.visibility = "hidden";
	}
	checkSubmitButton();
}

function checkPass(text) {
	let checkUpperCase = false;
	let checkLowerCase = false;
	let checNumber = false;
	let checkSymbols = false;
	let checkUpperCaseCount = 0;
	let checNumberCount = 0;
	let checkSymbolsCount = 0;
	let checkLowerCaseCount = 0;
	text = text.split("");
	for (let i = 0; i < text.length; i++) {
		if (
			text[i] == "@" ||
			text[i] == "_" ||
			text[i] == "-" ||
			text[i] == "!" ||
			text[i] == "?" ||
			text[i] == "%" ||
			text[i] == "&" ||
			text[i] == "·" ||
			text[i] == "\\" ||
			text[i] == "/"
		) {
			checkSymbols = true;
			checkSymbolsCount++;
		} else if (text[i].toUpperCase() == text[i] && isNaN(text[i])) {
			checkUpperCase = true;
			checkUpperCaseCount++;
		} else if (text[i].toLowerCase() == text[i] && isNaN(text[i])) {
			checkLowerCase = true;
			checkLowerCaseCount++;
		} else if (!isNaN(text[i])) {
			checNumber = true;
			checNumberCount++;
		}
	}
	if (checkUpperCase && checNumber && checkSymbols) {
		if (
			checkUpperCaseCount == 1 &&
			checkLowerCaseCount == 1 &&
			checNumberCount == 1 &&
			checkSymbolsCount == 1
		) {
			passElement.innerHTML = "poc segura";
		} else if (
			checkUpperCaseCount == 2 &&
			checkLowerCaseCount == 2 &&
			checNumberCount == 2 &&
			checkSymbolsCount == 2
		) {
			passElement.innerHTML = "segura";
		} else if (
			checkUpperCaseCount >= 3 &&
			checkLowerCaseCount >= 3 &&
			checNumberCount >= 3 &&
			checkSymbolsCount >= 3
		) {
			passElement.innerHTML = "molt segura";
		}
		checkPassElement.classList.add("correcte");
		checkPassElement.classList.remove("corregir");
		checkPassSubmit = true;
	} else {
		checkPassElement.classList.add("corregir");
		checkPassElement.classList.remove("correcte");
		checkPassSubmit = false;
	}
	if (text == "") {
		checkPassElement.classList.remove("correcte");
		checkPassElement.classList.remove("corregir");
		passElement.style.visibility = "hidden";
	} else {
		passElement.style.visibility = "visible";
	}
	if (text == "") {
		checkPassElement.classList.remove("corregir");
		checkPassElement.classList.remove("correcte");
		passElement.style.visibility = "hidden";
	}
	checkSubmitButton();
}
const dniElement = document.getElementById("dni");
const dniErrorExplainElement = document.getElementById("dniErrorExplain");
function checkDNI(value) {
	value = value.trim().replaceAll(" ", " ");
	if (value.length == 9) {
		let letter = value.charAt(8);
		let number = value.substring(0, 8);
		if (letras[number % 23] == letter) {
			dniErrorExplainElement.style.visibility = "hidden";
			dniElement.classList.remove("corregir");
			dniElement.classList.add("correcte");
			checkDNISubmit = true;
		} else {
			dniErrorExplainElement.style.visibility = "visible";
			dniErrorExplainElement.innerHTML =
				"El número no coincideix amb la lletra";
			dniElement.classList.remove("correcte");
			dniElement.classList.add("corregir");
		}
	} else {
		dniElement.classList.remove("correcte");
		dniElement.classList.add("corregir");
		dniErrorExplainElement.style.visibility = "visible";
		dniErrorExplainElement.innerHTML = "Introduieix un DNI";
	}
	if (value == "") {
		dniElement.classList.remove("corregir");
		dniElement.classList.remove("correcte");
		dniErrorExplainElement.style.visibility = "hidden";
	}
	checkSubmitButton();
}
function checkTextArea(text) {
	text = text.trim().replaceAll(" ", "").replaceAll("\n", "");
	console.log(text);
	countCharsElement.innerHTML = text.length;
	if (text.length > 5 && text.length < 650) {
		countCharsElement.style.color = "green";
		checkTextAreaSubmit = true;
	} else {
		countCharsElement.style.color = "red";
	}
	checkSubmitButton();
}
const totalPriceElement = document.getElementById("totalPrice");
function checkCities(citie, checked) {
	let price;
	if (citie == "estambul") {
		price = 300;
	} else if (citie == "ubud") {
		price = 400;
	} else if (citie == "kyoto") {
		price = 75;
	} else if (citie == "oaxaca") {
		price = 12.5;
	}
	if (checked == false) {
		totalPriceElement.innerHTML =
			parseFloat(totalPriceElement.innerHTML) + price;
	} else {
		totalPriceElement.innerHTML =
			parseFloat(totalPriceElement.innerHTML) - price;
	}
	if (totalPriceElement.innerHTML > 0) {
		checkCitiesSubmit = true;
	} else {
		checkCitiesSubmit = false;
	}
	checkSubmitButton();
}

function checkConditions(checked) {
	if (checked == false) {
		alert("S'han acceptat els acords i condicións");
		checkConditionsSubmit = true;
	} else {
		checkConditionsSubmit = false;
	}
	checkSubmitButton();
}
